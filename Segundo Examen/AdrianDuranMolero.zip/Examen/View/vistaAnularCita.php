<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ANULAR CITA</title>
</head>
<body>
    <div class="card">
        <table>
            <tr>
                <th>Doctor</th><td><?=$_SESSION['medico']?></td>
                <th>Hora</th><td></td>
            </tr>
        </table>
    </div>
</body>
</html>